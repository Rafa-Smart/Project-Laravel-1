@extends("templates.layout")
@section('content')
    <h2>ini About</h2>
@endsection