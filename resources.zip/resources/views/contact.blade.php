@extends("templates.layout")
@section('content')
    <h2>ini Contact</h2>
@endsection