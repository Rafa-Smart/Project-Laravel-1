@extends("templates.layout")
@section('content')
    <h2>ini home</h2>
@endsection